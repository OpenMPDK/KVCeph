===================
Libcephfs (JavaDoc)
===================

.. warning::

    CephFS Java bindings are no longer tested by CI. They may not work properly
    or corrupt data.

    Developers interested in reviving these bindings by fixing and writing tests
    are encouraged to contribute!

..
    The admin/build-docs script runs Ant to build the JavaDoc files, and
    copies them to api/libcephfs-java/javadoc/.


View the auto-generated `JavaDoc pages for the CephFS Java bindings <javadoc/>`_.
