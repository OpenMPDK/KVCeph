scan
====
This sub-command will allow to discover Ceph volumes previously setup by the
tool by looking into the system's logical volumes and their tags.

As part of the :ref:`ceph-volume-lvm-prepare` process, the logical volumes are assigned
a few tags with important pieces of information.

.. note:: This sub-command is not yet implemented
