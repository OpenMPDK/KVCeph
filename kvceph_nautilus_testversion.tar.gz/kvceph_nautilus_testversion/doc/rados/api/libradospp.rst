==================
 LibradosPP (C++)
==================

.. note:: The librados C++ API is not guaranteed to be API+ABI stable
   between major releases. All applications using the librados C++ API must
   be recompiled and relinked against a specific Ceph release.

.. todo:: write me!
