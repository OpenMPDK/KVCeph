Sepia community test lab
========================

The Ceph community maintains a test lab that is open to active contributors to
the Ceph project. Please see the `Sepia wiki`_ for more information.

.. _Sepia wiki: https://wiki.sepia.ceph.com/doku.php

