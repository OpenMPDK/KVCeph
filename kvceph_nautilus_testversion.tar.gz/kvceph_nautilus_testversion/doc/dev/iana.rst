IANA Numbers
============

Private Enterprise Number (PEN) Assignment
------------------------------------------

50495

Organization ``Ceph``.

Port number (monitor)
---------------------

3300

That's 0xce4, or ce4h, or (sort of) "ceph."
